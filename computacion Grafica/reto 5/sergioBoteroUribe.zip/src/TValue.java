
public class TValue {
	private double t = 0f;
	
	public TValue() {
		t = Double.MAX_VALUE;
	}

	public double getT() {
		return t;
	}

	public void setT(double t) {
		this.t = t;
	}
	
}
