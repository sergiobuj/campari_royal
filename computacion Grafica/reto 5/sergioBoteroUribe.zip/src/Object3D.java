
public abstract class Object3D {
	abstract boolean intersect(Ray r, Hit h, TValue tMin);
}
