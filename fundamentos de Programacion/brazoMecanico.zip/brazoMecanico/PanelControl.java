/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico
 * Autor: Mario S�nchez - 22/06/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

 

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

/**
 * En este panel se encuentran los botones utilizados para controlar el brazo mec�nico y ejecutar los retos
 */
public class PanelControl extends JPanel implements ActionListener
{
    //-----------------------------------------------------------------
    // Constantes
    //-----------------------------------------------------------------

    private static final String OPCION_1 = "OPCION_1";

    private static final String OPCION_2 = "OPCION_2";

    private static final String ARRIBA = "arriba";

    private static final String ABAJO = "abajo";

    private static final String DERECHA = "derecha";

    private static final String IZQUIERDA = "izquierda";

    private static final String AGARRAR_SOLTAR = "agarrar/soltar";

    //-----------------------------------------------------------------
    // Atributos de la Interfaz
    //-----------------------------------------------------------------

    /**
     * El bot�n para mover el brazo hacia la izquierda
     */
    private JButton botonIzquierda;

    /**
     * El bot�n para agarrar o soltar un cubo
     */
    private JButton botonAgarrarSoltar;

    /**
     * El bot�n para mover el brazo hacia abajo
     */
    private JButton botonAbajo;

    /**
     * El bot�n para mover el brazo hacia arriba
     */
    private JButton botonArriba;

    /**
     * El bot�n para mover el brazo hacia la derecha
     */
    private JButton botonDerecha;

    /**
     * El bot�n para ejecutar el reto 1
     */
    private JButton botonEjecutar1;

    /**
     * El bot�n para ejecutar el reto 2
     */
    private JButton botonEjecutar2;

    /**
     * El panel interno para organizar las flechas
     */
    private JPanel panelFlechas;

    /**
     * El panel interno para organizar los botones de los retos
     */
    private JPanel panelRetos;

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Es una referencia a la clase principal de la interfaz de la aplicaci�n
     */
    private InterfazBrazoMecanico interfazBrazo;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Construye el panel
     * @param iBrazo - Referencia a la clase principal de la interfaz - iBrazo != null
     */
    public PanelControl( InterfazBrazoMecanico iBrazo )
    {
        interfazBrazo = iBrazo;

        // Construir e inicializar los botones
        inicializarBotonAbajo( );
        inicializarBotonArriba( );
        inicializarBotonDerecha( );
        inicializarBotonIzquierda( );
        inicializarBotonAgarrar( );
        inicializarBotonEjecutar1( );
        inicializarBotonEjecutar2( );

        // Armar el panel para las flechas usando un GridLayout de 3x3
        panelFlechas = new JPanel( );
        panelFlechas.setLayout( new GridLayout( 3, 3 ) );

        panelFlechas.add( new JLabel( ) ); // Espacio vac�o arriba a la izquierda
        panelFlechas.add( botonArriba );
        panelFlechas.add( new JLabel( ) ); // Espacio vac�o arriba a la derecha
        panelFlechas.add( botonIzquierda );
        panelFlechas.add( botonAgarrarSoltar );
        panelFlechas.add( botonDerecha );
        panelFlechas.add( new JLabel( ) ); // Espacio vac�o abajo a la izquierda
        panelFlechas.add( botonAbajo );
        panelFlechas.add( new JLabel( ) ); // Espacio vac�o abajo a la derecha

        // Armar el panel para los botones de los retos
        panelRetos = new JPanel( );
        panelRetos.add( botonEjecutar1 );
        panelRetos.add( botonEjecutar2 );

        // Armar el panel completo
        add( panelFlechas, BorderLayout.WEST );
        add( panelRetos, BorderLayout.EAST );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonIzquierda( )
    {
        botonIzquierda = new JButton( );
        botonIzquierda.setIcon( new ImageIcon( "./data/izquierda.gif" ) );
        botonIzquierda.setActionCommand( IZQUIERDA );
        botonIzquierda.setMnemonic( java.awt.event.KeyEvent.VK_LEFT );
        botonIzquierda.addActionListener( this );
        botonIzquierda.setPreferredSize( new Dimension( 44, 44 ) );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonAgarrar( )
    {
        botonAgarrarSoltar = new JButton( );
        botonAgarrarSoltar.setActionCommand( AGARRAR_SOLTAR );
        botonAgarrarSoltar.setMnemonic( java.awt.event.KeyEvent.VK_S );
        botonAgarrarSoltar.setIcon( new ImageIcon( "./data/centro.gif" ) );
        botonAgarrarSoltar.addActionListener( this );
        botonAgarrarSoltar.setPreferredSize( new Dimension( 44, 44 ) );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonAbajo( )
    {
        botonAbajo = new JButton( );
        botonAbajo.setIcon( new ImageIcon( "./data/abajo.gif" ) );
        botonAbajo.setActionCommand( ABAJO );
        botonAbajo.setMnemonic( java.awt.event.KeyEvent.VK_DOWN );
        botonAbajo.addActionListener( this );
        botonAbajo.setPreferredSize( new Dimension( 44, 44 ) );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonArriba( )
    {
        botonArriba = new JButton( );
        botonArriba.setIcon( new ImageIcon( "./data/arriba.gif" ) );
        botonArriba.setActionCommand( ARRIBA );
        botonArriba.setMnemonic( java.awt.event.KeyEvent.VK_UP );
        botonArriba.addActionListener( this );
        botonArriba.setPreferredSize( new Dimension( 44, 44 ) );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonDerecha( )
    {
        botonDerecha = new JButton( );
        botonDerecha.setIcon( new ImageIcon( "./data/derecha.gif" ) );
        botonDerecha.setActionCommand( DERECHA );
        botonDerecha.setMnemonic( java.awt.event.KeyEvent.VK_RIGHT );
        botonDerecha.addActionListener( this );
        botonDerecha.setPreferredSize( new Dimension( 44, 44 ) );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonEjecutar1( )
    {
        botonEjecutar1 = new JButton( );
        botonEjecutar1.setText( "Opci�n 1" );
        botonEjecutar1.setActionCommand( OPCION_1 );
        botonEjecutar1.setMnemonic( java.awt.event.KeyEvent.VK_1 );
        botonEjecutar1.addActionListener( this );
    }

    /**
     * Inicializa y configura el bot�n
     */
    private void inicializarBotonEjecutar2( )
    {
        botonEjecutar2 = new JButton( );
        botonEjecutar2.setText( "Opci�n 2" );
        botonEjecutar2.setActionCommand( OPCION_2 );
        botonEjecutar2.setMnemonic( java.awt.event.KeyEvent.VK_2 );
        botonEjecutar2.addActionListener( this );
    }

    /**
     * Este m�todo se llama cuando se hace click sobre alguno de los botones
     * @param event - Es el evento del click sobre un bot�n
     */
    public void actionPerformed( ActionEvent event )
    {
        String actionCommand = event.getActionCommand( );
        if( actionCommand.equals( ARRIBA ) )
        {
            interfazBrazo.moverArriba( );
        }
        else if( actionCommand.equals( ABAJO ) )
        {
            interfazBrazo.moverAbajo( );
        }
        else if( actionCommand.equals( DERECHA ) )
        {
            interfazBrazo.moverDerecha( );
        }
        else if( actionCommand.equals( IZQUIERDA ) )
        {
            interfazBrazo.moverIzquierda( );
        }
        else if( actionCommand.equals( AGARRAR_SOLTAR ) )
        {
            interfazBrazo.agarrarSoltar( );
        }
        else if( actionCommand.equals( OPCION_1 ) )
        {
            interfazBrazo.reqFuncOpcion1( );
        }
        else if( actionCommand.equals( OPCION_2 ) )
        {
            interfazBrazo.reqFuncOpcion2( );
        }
    }
}
