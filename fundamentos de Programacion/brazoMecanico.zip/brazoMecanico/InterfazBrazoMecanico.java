/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico 
 * Autor: Mario S�nchez - 22/06/2005
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

 

import java.awt.*;
import java.io.*;

import javax.swing.*;



/**
 * Interfaz gr�fica del brazo mec�nico
 *  
 */
public class InterfazBrazoMecanico extends JFrame
{

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Bodega
     */
    private Bodega bodega;

    /**
     * Brazo mec�nico
     */
    private BrazoMecanico brazo;

    //-----------------------------------------------------------------
    // Atributos de la Interfaz
    //-----------------------------------------------------------------

    /**
     * El panel donde se muestra la bodega
     */
    private PanelBodega panelBodega;

    /**
     * El panel con los botones para controlar el brazo y ejecutar los retos
     */
    private PanelControl panelBotones;

    /**
     * El panel donde se ubica el panel de la bodega y el de los controles
     */
    private JPanel panelArriba;

    /**
     * El panel donde se muestra el estado del robot
     */
    private PanelEstado panelBarraEstado;

    /**
     * El men� con las opciones del mundo
     */
    private MenuBodega menuBodega;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Crea la interfaz con un brazo y una bodega
     * @param elBrazo - El brazo mec�nico - elBrazo != null
     * @param laBodega - La bodega dentro de la que est� el brazo - laBodega!=null
     */
    public InterfazBrazoMecanico( BrazoMecanico elBrazo, Bodega laBodega )
    {
        brazo = elBrazo;
        bodega = laBodega;

        // Construir los paneles
        panelBodega = new PanelBodega( brazo, bodega );
        panelBotones = new PanelControl( this );
        panelBarraEstado = new PanelEstado( );
        panelArriba = new JPanel( );

        // Armar la ventana
        panelArriba.setLayout( new BorderLayout( ) );
        panelArriba.add( panelBodega, BorderLayout.CENTER );
        panelArriba.add( panelBotones, BorderLayout.SOUTH );
        getContentPane().add( panelArriba, BorderLayout.CENTER );
        getContentPane().add( panelBarraEstado, BorderLayout.SOUTH );

        // Configurar las otras propiedades de la ventana
        setSize( 700, 600 );
        setTitle( "Brazo Mec�nico" );
        setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

        // Agregar el men�
        menuBodega = new MenuBodega( this );
        setJMenuBar( menuBodega );
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Actualiza la barra de estado con el mensaje indicado <br>
     * <b>post: </b>Se actualiz� la barra de estado y se mostr� el mensaje
     * @param mensaje - El mensaje que quiere mostrarse - mensaje!=null
     */
    public void actualizarBarraDeEstado( String mensaje )
    {
        panelBarraEstado.actualizarBarraDeEstado( mensaje, brazo.darPosX( ), brazo.darPosY( ), brazo.tieneCubo( ) );
    }

    /**
     * Carga un mundo a partir de un archivo <br>
     * <b>post: </b>Se carg� el mundo
     * @param archivo - El archivo que contiene el mundo - archivo!=null
     */
    public void cargarMundo( File archivo )
    {
        try
        {
            bodega.cargarMundo( archivo );
            brazo.reiniciar( );
            panelBodega.repaint( );
            actualizarBarraDeEstado( "Mundo cargado!" );
        }
        catch( Exception e1 )
        {
            JOptionPane.showMessageDialog( null, "Hubo un error cargando la bodega.\nAsegurese que el archivo tenga el formato correcto", "Error", JOptionPane.ERROR_MESSAGE );
            System.out.println( e1.getMessage( ) );
        }
    }

    /**
     * Mueve el brazo hacia arriba <br>
     * <b>post: </b>El brazo se movi� hacia arriba y la ventana se actualiz�
     */
    public void moverArriba( )
    {
        if( bodega.darIniciado( ) )
        {
            String mensaje = " ";
            try
            {
                brazo.mover( BrazoMecanico.ARRIBA );
            }
            catch( Exception e )
            {
                mensaje = "El brazo no puede moverse hacia arriba";
            }
            actualizarBarraDeEstado( mensaje );
            validate( );
        }
    }

    /**
     * Mueve el brazo hacia abajo. <br>
     * <b>post: </b>El brazo se movi� hacia abajo y la ventana se actualiz�
     */
    public void moverAbajo( )
    {
        if( bodega.darIniciado( ) )
        {
            String mensaje = " ";
            try
            {
                brazo.mover( BrazoMecanico.ABAJO );
            }
            catch( Exception e )
            {
                mensaje = "El brazo no puede moverse hacia abajo";
            }
            actualizarBarraDeEstado( mensaje );
            validate( );
        }
    }

    /**
     * Mueve el brazo hacia la derecha. <br>
     * <b>post: </b>El brazo se movi� hacia la derecha y la ventana se actualiz�
     */
    public void moverDerecha( )
    {
        if( bodega.darIniciado( ) )
        {
            String mensaje = " ";
            try
            {
                brazo.mover( BrazoMecanico.DERECHA );
            }
            catch( Exception e )
            {
                mensaje = "El brazo no puede moverse hacia la derecha";
            }
            actualizarBarraDeEstado( mensaje );
            validate( );
        }
    }

    /**
     * Mueve el brazo hacia la izquierda. <br>
     * <b>post: </b>El brazo se movi� hacia la izquierda y la ventana se actualiz�
     */
    public void moverIzquierda( )
    {
        if( bodega.darIniciado( ) )
        {
            String mensaje = " ";
            try
            {
                brazo.mover( BrazoMecanico.IZQUIERDA );
            }
            catch( Exception e )
            {
                mensaje = "El brazo no puede moverse hacia la izquierda";
            }
            actualizarBarraDeEstado( mensaje );
            validate( );
        }
    }

    /**
     * Hace que el brazo tome un cubo o lo suelte si ya est� cargando uno. <br>
     * <b>pre: </b>El brazo se encuentra en una posici�n donde puede tomar un cubo o puede soltarlo si est� cargando uno. <br>
     * <b>post: </b>El brazo toma o suelta el cubo
     */
    public void agarrarSoltar( )
    {
        if( bodega.darIniciado( ) )
        {
            String mensaje = " ";
            if( brazo.tieneCubo( ) )
            {
                try
                {
                    brazo.soltarCubo( );
                }
                catch( Exception e )
                {
                    mensaje = "No se puede soltar el cubo en esa posici�n";
                }
            }
            else
            {
                try
                {
                    brazo.agarrarCubo( );
                }
                catch( Exception e )
                {
                    mensaje = "No se puede agarrar el cubo en esa posici�n";
                }
            }
            actualizarBarraDeEstado( mensaje );
            validate( );
        }
    }

    /**
     * Punto de extensi�n 1
     */
    public void reqFuncOpcion1( )
    {
        if( bodega.darIniciado( ) )
        {
            try
            {
                brazo.metodo1( );
            }
            catch( Exception e )
            {
                JOptionPane.showMessageDialog( this, e.getMessage( ) );
            }
        }
    }

    /**
     * Punto de extensi�n 2
     */
    public void reqFuncOpcion2( )
    {
        if( bodega.darIniciado( ) )
        {
            try
            {
                brazo.metodo2( );
            }
            catch( Exception e )
            {
                JOptionPane.showMessageDialog( this, e.getMessage( ) );
            }
        }
    }

    /**
     * Este m�todo sirve para cargar un archivo de un mundo <br>
     * Muestra una ventana para seleccionar archivos y posteriormente carga la bodega seleccionada
     */
    public void cargar( )
    {
        JFileChooser fc = new JFileChooser( new File( "./data" ) );
        fc.setDialogTitle( "Cargar Bodega" );

        // Mostrar el dialogo para abrir
        int resultado = fc.showOpenDialog( null );
        if( resultado == JFileChooser.APPROVE_OPTION )
        {
            File archivo = fc.getSelectedFile( );
            cargarMundo( archivo );
        }
    }

    /**
     * Salir de la aplicaci�n
     */
    public void salir( )
    {
        System.exit( 0 );
    }

    //-----------------------------------------------------------------
    // Programa principal
    //-----------------------------------------------------------------

    /**
     * Construye un brazo y una bodega e inicializa la aplicaci�n
     * @param args Son los par�metros de ejecuci�n de la aplicaci�n. No se deben usar.
     */
    public static void main( String[] args )
    {
        Bodega bodega = new Bodega( );
        BrazoMecanico brazo = new BrazoMecanico( bodega );
        InterfazBrazoMecanico i = new InterfazBrazoMecanico( brazo, bodega );
        i.setVisible( true );
    }
}