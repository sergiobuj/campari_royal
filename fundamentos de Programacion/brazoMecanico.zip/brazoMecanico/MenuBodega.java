/**~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * $Id$ 
 * Universidad de los Andes (Bogot� - Colombia)
 * Departamento de Ingenier�a de Sistemas y Computaci�n 
 * Licenciado bajo el esquema Academic Free License version 2.1 
 *
 * Proyecto Cupi2 (http://cupi2.uniandes.edu.co)
 * Ejercicio: n4_brazoMecanico
 * Autor: Mario S�nchez - 22/06/2005 
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~ 
 */

 

import java.awt.event.*;

import javax.swing.*;

/**
 * Es la barra de men� para controlar la aplicaci�n
 */
public class MenuBodega extends JMenuBar implements ActionListener
{
    //-----------------------------------------------------------------
    // Constantes
    //-----------------------------------------------------------------

    private static final String CARGAR = "cargar";
    private static final String SALIR = "salir";

    //-----------------------------------------------------------------
    // Atributos de la Interfaz
    //-----------------------------------------------------------------

    /**
     * Es el men� "Bodega"
     */
    private JMenu menuBodega;

    /**
     * Es la opci�n "Cargar"
     */
    private JMenuItem menuCargar;

    /**
     * Es la opci�n "Salir"
     */
    private JMenuItem menuSalir;

    //-----------------------------------------------------------------
    // Atributos
    //-----------------------------------------------------------------

    /**
     * Es una referencia a la clase principal de la interfaz de la aplicaci�n
     */
    private InterfazBrazoMecanico interfazBrazo;

    //-----------------------------------------------------------------
    // Constructores
    //-----------------------------------------------------------------

    /**
     * Construye el men�
     * @param iBrazo - Es una referencia a la clase principal de la interfaz de la aplicaci�n - iBrazo!=null
     */
    public MenuBodega( InterfazBrazoMecanico iBrazo )
    {
        interfazBrazo = iBrazo;
        menuBodega = new JMenu( );
        menuBodega.setText( "Bodega" );
        menuBodega.setMnemonic( java.awt.event.KeyEvent.VK_J );

        inicializarMenuCargar( );
        inicializarMenuSalir( );

        menuBodega.add( menuCargar );
        menuBodega.add( menuSalir );

        add( menuBodega );
    }

    //-----------------------------------------------------------------
    // M�todos
    //-----------------------------------------------------------------

    /**
     * Este m�todo inicializa el men� de cargar
     */
    private void inicializarMenuCargar( )
    {
        menuCargar = new JMenuItem( );
        menuCargar.setActionCommand( CARGAR );
        menuCargar.setText( "Cargar Bodega" );
        menuCargar.setAccelerator( javax.swing.KeyStroke.getKeyStroke( java.awt.event.KeyEvent.VK_F2, 0, true ) );
        menuCargar.setMnemonic( java.awt.event.KeyEvent.VK_C );
        menuCargar.addActionListener( this );
    }

    /**
     * Este m�todo inicializa el men� de salir
     */
    private void inicializarMenuSalir( )
    {
        menuSalir = new JMenuItem( );
        menuSalir.setActionCommand( SALIR );
        menuSalir.setText( "Salir" );
        menuSalir.setMnemonic( java.awt.event.KeyEvent.VK_S );
        menuSalir.addActionListener( this );
    }

    /**
     * Este m�todo se llama cuando se selecciona una opci�n del men�
     * @param evento - Es el evento del click sobre una opci�n
     */
    public void actionPerformed( ActionEvent evento )
    {
        String comando = evento.getActionCommand( );
        if( comando.equals( CARGAR ) )
        {
            interfazBrazo.cargar( );
        }
        else if( comando.equals( SALIR ) )
        {
            interfazBrazo.salir( );
        }
    }
}
